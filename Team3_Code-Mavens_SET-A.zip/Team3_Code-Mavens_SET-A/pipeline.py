
import math
from datetime import datetime

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")  
import matplotlib.pyplot as plt

import folium
from folium.plugins import HeatMap


# =====================================================================================
# CONSTANTS
# =====================================================================================

VALID_ZONES = ["North", "South", "East", "West", "Central"]

ZONE_COORDS = {
    "North": [28.8000, 77.2090],
    "South": [28.4595, 77.0266],
    "East": [28.6139, 77.3910],
    "West": [28.6139, 77.0270],
    "Central": [28.6139, 77.2090],
}

CLEANED_CSV_PATH = "cleaned_ridership.csv"
DASHBOARD_PNG_PATH = "mobility_dashboard.png"
MAP_HTML_PATH = "city_mobility_map.html"

PEAK_HIGH_THRESHOLD = 3500
PEAK_MEDIUM_THRESHOLD = 1500

MAP_GREEN_THRESHOLD = 2000
MAP_ORANGE_THRESHOLD = 3500

OUTLIER_Z_THRESHOLD = 3.0
OUTLIER_CAP_PERCENTILE = 99.0


# =====================================================================================
# STARTER CODE (DATA GENERATION + NOISE INJECTION) 
# =====================================================================================

def generate_raw_data() -> pd.DataFrame:
    """
    Recreates the exact noisy dataset described in the problem statement.
    Seeded so the run is fully reproducible.
    """
    np.random.seed(42)
    n = 500
    rng = np.random.default_rng(42)

    # --- Base data ---
    passengers = np.random.randint(200, 5000, n).astype(object)
    delay_min = np.random.choice([np.nan, 0, 5, 10, 15, 30], n)
    zone = list(np.random.choice(["North", "South", "East", "West", "Central"], n))
    route_id = list(np.random.choice([f"R{i:02d}" for i in range(1, 51)], n))
    dates = list(pd.date_range("2022-01-01", periods=n, freq="D"))

    # --- NOISE INJECTION  ---
    idx = rng.choice(n, size=40, replace=False)
    for i in idx[:15]:
        passengers[i] = np.nan  # missing values
    for i in idx[15:25]:
        passengers[i] = str(passengers[i] or 0).split(".")[0] + " pax"  # dirty strings
    for i in idx[25:32]:
        zone[i] = zone[i].lower()  # case inconsistency
    for i in idx[32:37]:
        route_id[i] = " " + route_id[i] + " "  # whitespace
    for i in idx[37:40]:
        delay_min[i] = -999  # bad sentinel
    for i in rng.choice(n, 8):
        passengers[i] = 99999  # outlier spikes

    df = pd.DataFrame(
        {
            "route_id": route_id,
            "date": dates,
            "passengers": passengers,
            "delay_min": delay_min,
            "zone": zone,
        }
    )
    return df


# =====================================================================================
# TASK 1: DATA INGESTION & CLEANING
# =====================================================================================

def clean_passengers(df: pd.DataFrame) -> pd.DataFrame:
    """
    Subtask 1: Fix 'passengers'.
      - Coerce dirty strings ('2443 pax') to numeric.
      - Fill NaN with column median.
      - Detect outliers via z-score (>3 sigma) and cap them to the 99th percentile.

    Note: dirty strings like '2443 pax' are first stripped of their trailing
    non-numeric suffix using a regex extraction, THEN passed through
    pd.to_numeric(errors='coerce') so genuinely unparsable values become NaN
    while values like '2443 pax' correctly become 2443, not NaN.
    """
    series = df["passengers"].astype(str)

    # Extract the leading numeric portion of every value (handles '2443 pax', '2443.0', etc.)
    extracted = series.str.extract(r"(-?\d+\.?\d*)")[0]
    numeric = pd.to_numeric(extracted, errors="coerce")

    # Fill NaN (true missing values + unparsable strings) with the column median
    median_value = numeric.median()
    numeric = numeric.fillna(median_value)

    # Outlier detection via z-score, computed on the now-numeric, NaN-free series
    mean_val = numeric.mean()
    std_val = numeric.std(ddof=0)
    if std_val == 0 or math.isnan(std_val):
        z_scores = pd.Series(np.zeros(len(numeric)), index=numeric.index)
    else:
        z_scores = (numeric - mean_val) / std_val

    is_outlier = z_scores.abs() > OUTLIER_Z_THRESHOLD
    # Cap value is computed from the NON-outlier subset only, so the spikes
    # themselves don't inflate the percentile they are about to be capped to.
    non_outlier_values = numeric[~is_outlier]
    cap_value = np.percentile(non_outlier_values, OUTLIER_CAP_PERCENTILE)
    numeric = numeric.where(~is_outlier, cap_value)

    df["passengers"] = numeric.astype(float)
    return df


def clean_delay(df: pd.DataFrame) -> pd.DataFrame:
    """
    Subtask 2: Fix 'delay_min'.
      - Replace the -999 sentinel with NaN.
      - Fill remaining NaN with the ROUTE-WISE median delay (per route_id group),
        not a single global median.
      - Fallback: if an entire route's delay values are all NaN (no valid
        median can be computed for that route), fall back to the global median.
    """
    delay = df["delay_min"].replace(-999, np.nan)
    df["delay_min"] = delay

    route_median = df.groupby("route_id")["delay_min"].transform("median")
    global_median = df["delay_min"].median()

    filled = df["delay_min"].fillna(route_median)
    filled = filled.fillna(global_median)  # edge case: route had no valid delays at all
    df["delay_min"] = filled
    return df


def clean_zone(df: pd.DataFrame) -> pd.DataFrame:
    """
    Subtask 3: Fix 'zone'.
      - Strip whitespace.
      - Standardise casing to Title Case.
      - Restrict to {North, South, East, West, Central}; anything outside this
        set is treated as missing and back-filled with the most frequent
        (mode) zone, as a defensive edge-case guard.
    """
    cleaned = df["zone"].astype(str).str.strip().str.title()
    invalid_mask = ~cleaned.isin(VALID_ZONES)
    if invalid_mask.any():
        mode_zone = cleaned[~invalid_mask].mode()
        fallback = mode_zone.iloc[0] if not mode_zone.empty else VALID_ZONES[0]
        cleaned = cleaned.where(~invalid_mask, fallback)
    df["zone"] = cleaned
    return df


def clean_route_id(df: pd.DataFrame) -> pd.DataFrame:
    """Subtask 4: Fix 'route_id' - strip leading/trailing whitespace."""
    df["route_id"] = df["route_id"].astype(str).str.strip()
    return df


def add_derived_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Subtask 5: Add derived columns.
      - peak_load: 'High' (>3500), 'Medium' (1500-3500 inclusive), 'Low' (otherwise).
      - day_of_week: derived from the 'date' column (Monday=0 ... Sunday=6 names).
    """

    def classify_peak(passengers_value: float) -> str:
        if passengers_value > PEAK_HIGH_THRESHOLD:
            return "High"
        if passengers_value >= PEAK_MEDIUM_THRESHOLD:
            return "Medium"
        return "Low"

    df["peak_load"] = df["passengers"].apply(classify_peak)
    df["date"] = pd.to_datetime(df["date"])
    df["day_of_week"] = df["date"].dt.day_name()
    return df


def run_etl(raw_df: pd.DataFrame, verbose: bool = True) -> tuple:
    """
    Orchestrates Task 1 end-to-end:
      load -> clean passengers -> clean delay -> clean zone -> clean route_id
           -> add derived columns -> export CSV -> print null counts before/after.

    Returns
    -------
    (cleaned_df, meta) where meta is a dict with 'nulls_before', 'nulls_after',
    'sentinel_count' and 'csv_path' - used by both the CLI and the Streamlit
    frontend to display the same numbers without re-deriving them.
    """
    if verbose:
        print("=" * 80)
        print("TASK 1: DATA INGESTION & CLEANING")
        print("=" * 80)

    nulls_before = raw_df.isna().sum()
    sentinel_count = int((raw_df["delay_min"] == -999).sum())

    if verbose:
        print("\nNull counts BEFORE cleaning:")
        print(nulls_before.to_string())
        print(f"  delay_min == -999 sentinel count: {sentinel_count}")

    df = raw_df.copy()
    df = clean_passengers(df)
    df = clean_delay(df)
    df = clean_zone(df)
    df = clean_route_id(df)
    df = add_derived_columns(df)

    nulls_after = df.isna().sum()

    if verbose:
        print("\nNull counts AFTER cleaning:")
        print(nulls_after.to_string())

    df.to_csv(CLEANED_CSV_PATH, index=False)

    if verbose:
        print(f"\nSaved cleaned dataset -> {CLEANED_CSV_PATH}  (shape={df.shape})")

    meta = {
        "nulls_before": nulls_before,
        "nulls_after": nulls_after,
        "sentinel_count": sentinel_count,
        "csv_path": CLEANED_CSV_PATH,
    }
    return df, meta


# =====================================================================================
# TASK 2: ALGORITHM - ROUTE EFFICIENCY RANKING (CUSTOM MERGE SORT)
# =====================================================================================

def merge_sort(arr: list, key=lambda x: x, descending: bool = True) -> list:
    """
    Fully custom Merge Sort implementation (no built-in sort()/sorted() used
    anywhere in this function). Stable, O(n log n), works on any list of
    items given a key-extraction function.

    Parameters
    ----------
    arr : list
        List of items to sort.
    key : callable
        Function extracting the comparison value from each item.
    descending : bool
        Sort order. True = descending (largest first).

    Returns
    -------
    list: a new sorted list (input list is not mutated).
    """
    if len(arr) <= 1:
        return list(arr)

    mid = len(arr) // 2
    left = merge_sort(arr[:mid], key=key, descending=descending)
    right = merge_sort(arr[mid:], key=key, descending=descending)

    return _merge(left, right, key=key, descending=descending)


def _merge(left: list, right: list, key, descending: bool) -> list:
    """Merge step for merge_sort(). Stable: ties keep left-before-right order."""
    merged = []
    i, j = 0, 0
    while i < len(left) and j < len(right):
        left_val = key(left[i])
        right_val = key(right[j])
        take_left = (left_val >= right_val) if descending else (left_val <= right_val)
        if take_left:
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged


def compute_route_stats(df: pd.DataFrame) -> pd.DataFrame:
    """
    Subtask 1: Per-route avg_passengers and avg_delay_min via groupby.
    Also captures the dominant (mode) peak_load category per route, which is
    reused later by the Folium map module for zone-level popups.
    """
    grouped = df.groupby("route_id").agg(
        avg_passengers=("passengers", "mean"),
        avg_delay_min=("delay_min", "mean"),
    ).reset_index()
    return grouped


def rank_routes(stats_df: pd.DataFrame, verbose: bool = True):
    """
    Subtasks 2-5:
      - Build (route_id, avg_passengers, avg_delay) tuples.
      - Merge-sort rank #1: descending by avg_passengers.
      - Compute efficiency_score = avg_passengers / (1 + avg_delay).
      - Merge-sort rank #2: descending by efficiency_score.
      - Assert the final ranking is non-increasing by efficiency_score.
      - Print Top 5 / Bottom 5 by efficiency_score in a formatted table.

    Returns
    -------
    list of dict: each containing route_id, avg_passengers, avg_delay,
                  efficiency_score - sorted descending by efficiency_score.
    """
    if verbose:
        print("\n" + "=" * 80)
        print("TASK 2: ALGORITHM - ROUTE EFFICIENCY RANKING (Custom Merge Sort)")
        print("=" * 80)

    records = list(
        stats_df[["route_id", "avg_passengers", "avg_delay_min"]].itertuples(
            index=False, name=None
        )
    )
    # records: list of (route_id, avg_passengers, avg_delay)

    # --- Ranking pass 1: by avg_passengers, descending ---
    ranked_by_passengers = merge_sort(records, key=lambda t: t[1], descending=True)

    if verbose:
        print("\nTop 5 routes by avg_passengers (Merge Sort pass 1):")
        _print_table(
            [(r[0], round(r[1], 2), round(r[2], 2)) for r in ranked_by_passengers[:5]],
            headers=("route_id", "avg_passengers", "avg_delay_min"),
        )

    # --- Compute efficiency_score ---
    enriched = []
    for route_id, avg_passengers, avg_delay in ranked_by_passengers:
        safe_avg_delay = 0.0 if pd.isna(avg_delay) else avg_delay
        efficiency_score = avg_passengers / (1.0 + safe_avg_delay)
        enriched.append(
            {
                "route_id": route_id,
                "avg_passengers": avg_passengers,
                "avg_delay_min": safe_avg_delay,
                "efficiency_score": efficiency_score,
            }
        )

    # --- Ranking pass 2: by efficiency_score, descending ---
    final_ranking = merge_sort(
        enriched, key=lambda d: d["efficiency_score"], descending=True
    )

    # --- Correctness assertion: strictly non-increasing (allows ties) ---
    scores = [d["efficiency_score"] for d in final_ranking]
    for a, b in zip(scores, scores[1:]):
        assert a >= b, "Merge sort output is not non-increasing by efficiency_score!"

    if verbose:
        print("\n[OK] Assertion passed: efficiency_score ranking is non-increasing.")

        print("\nTop 5 routes by efficiency_score:")
        _print_table(
            [
                (d["route_id"], round(d["avg_passengers"], 2),
                 round(d["avg_delay_min"], 2), round(d["efficiency_score"], 4))
                for d in final_ranking[:5]
            ],
            headers=("route_id", "avg_passengers", "avg_delay_min", "efficiency_score"),
        )

        print("\nBottom 5 routes by efficiency_score:")
        _print_table(
            [
                (d["route_id"], round(d["avg_passengers"], 2),
                 round(d["avg_delay_min"], 2), round(d["efficiency_score"], 4))
                for d in final_ranking[-5:]
            ],
            headers=("route_id", "avg_passengers", "avg_delay_min", "efficiency_score"),
        )

    return final_ranking


def _print_table(rows, headers):
    """Small utility to pretty-print a list of tuples as a fixed-width table."""
    col_widths = [
        max(len(str(h)), max((len(str(r[i])) for r in rows), default=0))
        for i, h in enumerate(headers)
    ]
    header_line = " | ".join(str(h).ljust(col_widths[i]) for i, h in enumerate(headers))
    print(header_line)
    print("-" * len(header_line))
    for row in rows:
        print(" | ".join(str(v).ljust(col_widths[i]) for i, v in enumerate(row)))


# =====================================================================================
# TASK 3: STATISTICAL VISUALIZATION (NUMPY + MATPLOTLIB)
# =====================================================================================

def plot_panel_1_timeseries(ax, df: pd.DataFrame) -> None:
    """Panel 1: daily total passengers over time + 7-day rolling mean overlay."""
    daily = df.groupby("date")["passengers"].sum().sort_index()
    rolling = daily.rolling(window=7, min_periods=1).mean()

    ax.plot(daily.index, daily.values, label="Daily total passengers",
            color="#4C72B0", linewidth=1.0, alpha=0.7)
    ax.plot(rolling.index, rolling.values, label="7-day rolling mean",
            color="#DD8452", linewidth=2.0)
    ax.set_title("Daily Total Passengers Over Time")
    ax.set_xlabel("Date")
    ax.set_ylabel("Total Passengers (count)")
    ax.legend(loc="best", fontsize=8)
    ax.tick_params(axis="x", rotation=30)


def plot_panel_2_grouped_bar(ax, df: pd.DataFrame) -> None:
    """Panel 2: grouped bar chart of avg passengers by zone and peak_load category."""
    grouped = (
        df.groupby(["zone", "peak_load"])["passengers"]
        .mean()
        .unstack(fill_value=0)
        .reindex(columns=["Low", "Medium", "High"], fill_value=0)
        .reindex(index=VALID_ZONES, fill_value=0)
    )

    zones = grouped.index.tolist()
    categories = grouped.columns.tolist()
    x = np.arange(len(zones))
    bar_width = 0.8 / len(categories)
    colors = {"Low": "#55A868", "Medium": "#DD8452", "High": "#C44E52"}

    for i, category in enumerate(categories):
        offset = (i - (len(categories) - 1) / 2) * bar_width
        ax.bar(
            x + offset,
            grouped[category].values,
            width=bar_width,
            label=category,
            color=colors.get(category, None),
        )

    ax.set_title("Avg Passengers by Zone & Peak Load Category")
    ax.set_xlabel("Zone")
    ax.set_ylabel("Avg Passengers (count)")
    ax.set_xticks(x)
    ax.set_xticklabels(zones)
    ax.legend(title="Peak Load", fontsize=8)


def plot_panel_3_histogram(ax, df: pd.DataFrame) -> None:
    """Panel 3: histogram of delay_min distribution with a normal-curve overlay."""
    delay_values = df["delay_min"].dropna().values
    mean_val = np.mean(delay_values)
    std_val = np.std(delay_values)

    counts, bin_edges, _ = ax.hist(
        delay_values, bins=20, density=True, color="#4C72B0",
        alpha=0.7, edgecolor="white", label="Observed delay distribution",
    )

    x_curve = np.linspace(bin_edges[0], bin_edges[-1], 200)
    if std_val > 0:
        normal_curve = (1.0 / (std_val * np.sqrt(2 * np.pi))) * np.exp(
            -0.5 * ((x_curve - mean_val) / std_val) ** 2
        )
        ax.plot(x_curve, normal_curve, color="#C44E52", linewidth=2.0,
                 label=f"Normal fit (μ={mean_val:.1f}, σ={std_val:.1f})")

    ax.set_title("Delay Distribution (minutes)")
    ax.set_xlabel("Delay (min)")
    ax.set_ylabel("Density")
    ax.legend(fontsize=8)


def plot_panel_4_scatter(ax, route_stats: pd.DataFrame, df: pd.DataFrame) -> None:
    """Panel 4: scatter of avg_passengers vs avg_delay per route, colored by zone,
    with the top-10 routes (by avg_passengers) labelled."""
    # Determine each route's dominant (most frequent) zone for coloring
    route_zone = (
        df.groupby("route_id")["zone"]
        .agg(lambda s: s.mode().iloc[0] if not s.mode().empty else "Central")
    )
    merged = route_stats.merge(route_zone.rename("zone"), on="route_id", how="left")

    zone_colors = {
        "North": "#4C72B0", "South": "#DD8452", "East": "#55A868",
        "West": "#C44E52", "Central": "#8172B2",
    }

    for zone_name in VALID_ZONES:
        subset = merged[merged["zone"] == zone_name]
        ax.scatter(
            subset["avg_delay_min"], subset["avg_passengers"],
            label=zone_name, color=zone_colors.get(zone_name), s=45,
            edgecolor="white", linewidth=0.5,
        )

    top10 = merged.sort_values("avg_passengers", ascending=False).head(10)
    for _, row in top10.iterrows():
        ax.annotate(
            row["route_id"],
            (row["avg_delay_min"], row["avg_passengers"]),
            fontsize=7, xytext=(3, 3), textcoords="offset points",
        )

    ax.set_title("Avg Passengers vs Avg Delay per Route (Top-10 labelled)")
    ax.set_xlabel("Avg Delay (min)")
    ax.set_ylabel("Avg Passengers (count)")
    ax.legend(title="Zone", fontsize=8)


def build_dashboard(df: pd.DataFrame, route_stats: pd.DataFrame, verbose: bool = True):
    """
    Orchestrates Task 3: builds the 4-panel figure and saves it as
    mobility_dashboard.png at 150 DPI using plt.tight_layout().

    Returns the matplotlib Figure object (already saved to disk) so the
    Streamlit frontend can render it directly via st.pyplot(fig) without a
    disk round-trip.
    """
    if verbose:
        print("\n" + "=" * 80)
        print("TASK 3: STATISTICAL VISUALIZATION")
        print("=" * 80)

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    plot_panel_1_timeseries(axes[0, 0], df)
    plot_panel_2_grouped_bar(axes[0, 1], df)
    plot_panel_3_histogram(axes[1, 0], df)
    plot_panel_4_scatter(axes[1, 1], route_stats, df)

    fig.suptitle("Urban Mobility Analytics Dashboard", fontsize=16, fontweight="bold")
    plt.tight_layout(rect=(0, 0, 1, 0.97))
    fig.savefig(DASHBOARD_PNG_PATH, dpi=150)

    if verbose:
        print(f"Saved 4-panel dashboard -> {DASHBOARD_PNG_PATH} (150 DPI)")

    return fig


# =====================================================================================
# TASK 4: INTERACTIVE ZONE MAP (FOLIUM)
# =====================================================================================

def compute_zone_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregates cleaned data per zone: avg passengers, avg delay, dominant peak_load."""

    def dominant_category(series: pd.Series) -> str:
        mode = series.mode()
        return mode.iloc[0] if not mode.empty else "Low"

    summary = df.groupby("zone").agg(
        avg_passengers=("passengers", "mean"),
        avg_delay_min=("delay_min", "mean"),
    )
    summary["dominant_peak_load"] = df.groupby("zone")["peak_load"].agg(dominant_category)
    summary = summary.reindex(VALID_ZONES)  # guarantee a deterministic, complete zone set
    return summary.reset_index()


def marker_color_for_passengers(avg_passengers: float) -> str:
    """Color logic: green <2000, orange 2000-3500, red >3500."""
    if avg_passengers < MAP_GREEN_THRESHOLD:
        return "green"
    if avg_passengers <= MAP_ORANGE_THRESHOLD:
        return "orange"
    return "red"


def build_zone_markers(map_obj: folium.Map, zone_summary: pd.DataFrame) -> None:
    """Subtasks 2-3: one CircleMarker per zone with radius/color/popup logic."""
    for _, row in zone_summary.iterrows():
        zone_name = row["zone"]
        if zone_name not in ZONE_COORDS or pd.isna(row["avg_passengers"]):
            continue  # defensive guard: skip zones with no data / unknown coords

        avg_passengers = float(row["avg_passengers"])
        avg_delay = float(row["avg_delay_min"]) if not pd.isna(row["avg_delay_min"]) else 0.0
        radius = max(avg_passengers / 200.0, 3.0)  # floor radius so tiny zones stay visible

        popup_html = (
            f"<b>Zone:</b> {zone_name}<br>"
            f"<b>Avg Passengers:</b> {avg_passengers:.1f}<br>"
            f"<b>Avg Delay (min):</b> {avg_delay:.1f}<br>"
            f"<b>Dominant Peak Load:</b> {row['dominant_peak_load']}"
        )

        folium.CircleMarker(
            location=ZONE_COORDS[zone_name],
            radius=radius,
            color=marker_color_for_passengers(avg_passengers),
            fill=True,
            fill_color=marker_color_for_passengers(avg_passengers),
            fill_opacity=0.7,
            popup=folium.Popup(popup_html, max_width=250),
            tooltip=zone_name,
        ).add_to(map_obj)


def build_heatmap_layer(map_obj: folium.Map, df: pd.DataFrame, seed: int = 42) -> int:
    """
    Subtask 4: HeatMap layer using ALL data points, with lat/lon jittered
    +/-0.02 around each row's zone centroid. Returns the number of points used.
    """
    rng = np.random.default_rng(seed)
    heat_points = []

    for _, row in df.iterrows():
        zone_name = row["zone"]
        if zone_name not in ZONE_COORDS:
            continue
        base_lat, base_lon = ZONE_COORDS[zone_name]
        jitter_lat = rng.uniform(-0.02, 0.02)
        jitter_lon = rng.uniform(-0.02, 0.02)
        weight = row["passengers"] if not pd.isna(row["passengers"]) else 0.0
        heat_points.append([base_lat + jitter_lat, base_lon + jitter_lon, weight])

    HeatMap(heat_points, radius=18, blur=22, max_zoom=13).add_to(map_obj)
    return len(heat_points)


def build_zone_map(df: pd.DataFrame, verbose: bool = True):
    """
    Orchestrates Task 4: builds the Folium map (zone markers + heatmap),
    saves it as city_mobility_map.html, and prints the total marker count.

    Returns
    -------
    (city_map, stats) where stats = {'zone_summary', 'n_zone_markers',
    'n_heat_points'} - used by the Streamlit frontend to render the map
    inline and show the same counts as the CLI.
    """
    if verbose:
        print("\n" + "=" * 80)
        print("TASK 4: INTERACTIVE ZONE MAP (Folium)")
        print("=" * 80)

    zone_summary = compute_zone_summary(df)

    city_map = folium.Map(location=[28.6139, 77.2090], zoom_start=11, tiles="OpenStreetMap")

    build_zone_markers(city_map, zone_summary)
    n_heat_points = build_heatmap_layer(city_map, df)

    folium.LayerControl().add_to(city_map)
    city_map.save(MAP_HTML_PATH)

    n_zone_markers = int(zone_summary["zone"].isin(ZONE_COORDS).sum())

    if verbose:
        print(f"Zone CircleMarkers placed: {n_zone_markers}")
        print(f"HeatMap points plotted (all rows, jittered): {n_heat_points}")
        print(f"Total marker count: {n_zone_markers}")
        print(f"Saved interactive map -> {MAP_HTML_PATH}")

    stats = {
        "zone_summary": zone_summary,
        "n_zone_markers": n_zone_markers,
        "n_heat_points": n_heat_points,
        "html_path": MAP_HTML_PATH,
    }
    return city_map, stats


# =====================================================================================
# TOP-LEVEL ORCHESTRATOR (used by both the CLI and the Streamlit frontend)
# =====================================================================================

def run_pipeline(verbose: bool = True) -> dict:
    """
    Runs all 4 tasks end-to-end and returns every intermediate artifact in a
    single dict, so any frontend (CLI or Streamlit) can render results
    without re-deriving anything or re-reading files from disk.
    """
    raw_df = generate_raw_data()

    cleaned_df, etl_meta = run_etl(raw_df, verbose=verbose)
    route_stats = compute_route_stats(cleaned_df)
    ranking = rank_routes(route_stats, verbose=verbose)
    fig = build_dashboard(cleaned_df, route_stats, verbose=verbose)
    city_map, map_stats = build_zone_map(cleaned_df, verbose=verbose)

    return {
        "raw_df": raw_df,
        "cleaned_df": cleaned_df,
        "etl_meta": etl_meta,
        "route_stats": route_stats,
        "ranking": ranking,
        "dashboard_fig": fig,
        "city_map": city_map,
        "map_stats": map_stats,
    }



