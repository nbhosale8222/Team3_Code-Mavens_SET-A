# Urban Mobility Analytics — Set A

Python Data Science Hackathon submission: ETL, a custom Merge-Sort route
ranking, a 4-panel statistical dashboard, and an interactive Folium zone map
— available both as a CLI script and as an interactive Streamlit frontend.

## Project structure

```
.
├── pipeline.py     # All business logic (Tasks 1-4). Import this, don't run it directly.
├── solution.py     # CLI entry point — exact grading deliverable. Run: python solution.py
├── app.py          # Interactive Streamlit frontend. Run: streamlit run app.py
├── requirements.txt
└── README.md
```

`solution.py` and `app.py` both call the same functions in `pipeline.py`, so
the numbers, files, and logic are identical in both — the frontend is a
view layer on top of the graded pipeline, not a separate implementation.

## Setup

```bash
pip install -r requirements.txt
```

## Run the CLI (grading deliverable)

```bash
python solution.py
```

Produces, in the current directory:
- `cleaned_ridership.csv`
- `mobility_dashboard.png`
- `city_mobility_map.html`

## Run the interactive frontend

```bash
streamlit run app.py
```

Opens a browser tab with 5 tabs:
1. **Task 1 — ETL**: before/after null counts, zone & peak_load distributions, raw vs cleaned data preview.
2. **Task 2 — Ranking**: live merge-sort route rankings, adjustable Top-N slider, correctness check.
3. **Task 3 — Dashboard**: the same 4-panel matplotlib figure, rendered inline.
4. **Task 4 — Zone Map**: the live, clickable Folium map embedded directly in the page.
5. **Downloads**: one-click download buttons for all 3 deliverable files.

Use the "🔄 Re-run pipeline" button in the sidebar to clear the cache and
recompute everything from scratch (useful after editing `pipeline.py`).

## Notes

- The dataset is synthetic and seeded (`np.random.seed(42)`), so every run —
  CLI or Streamlit — is fully reproducible.
- All cleaning logic, the custom Merge Sort, and the visualization/map code
  live in `pipeline.py` only; `solution.py` and `app.py` contain no
  duplicated business logic.
