

import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st
from streamlit_folium import st_folium

import pipeline

# =====================================================================================
# PAGE CONFIG
# =====================================================================================

st.set_page_config(
    page_title="UrbanPulse",
    page_icon="🚌",
    layout="wide",
    initial_sidebar_state="expanded",
)

# =====================================================================================
# GLOBAL CSS — dark command-center theme
# =====================================================================================
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

/* ── KPI cards ── */
.kpi-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 14px; margin-bottom: 24px; }
.kpi-card {
    background: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 10px;
    padding: 18px 20px;
}
.kpi-card:hover { border-color: #6366f1; }
.kpi-label { font-size: 0.72rem; color: #6b7280; text-transform: uppercase; letter-spacing: 0.07em; font-weight: 600; margin-bottom: 6px; }
.kpi-value { font-size: 1.9rem; font-weight: 700; color: #111827; line-height: 1; }
.kpi-sub { font-size: 0.75rem; color: #9ca3af; margin-top: 4px; }

/* ── Hero header ── */
.up-hero {
    background: #f9fafb;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 24px 32px;
    margin-bottom: 24px;
    display: flex;
    align-items: center;
    gap: 20px;
}
.up-logo-ring {
    width: 64px; height: 64px; flex-shrink: 0;
    border-radius: 12px;
    background: #6366f1;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.8rem;
}
.up-hero-text h1 {
    font-size: 1.8rem; font-weight: 700;
    color: #111827;
    margin: 0 0 4px 0; line-height: 1.1;
}
.up-hero-text .tagline { color: #6b7280; font-size: 0.88rem; margin: 0; }
.up-badges { display: flex; gap: 8px; margin-top: 10px; flex-wrap: wrap; }
.up-badge {
    background: #eff6ff; border: 1px solid #bfdbfe;
    border-radius: 20px; padding: 3px 12px;
    font-size: 0.72rem; font-weight: 600; color: #3b82f6;
    text-transform: uppercase; letter-spacing: 0.05em;
}

/* ── Status bar ── */
.status-bar {
    display: flex; gap: 20px; align-items: center;
    background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px;
    padding: 10px 16px; margin-bottom: 20px; font-size: 0.78rem; color: #9ca3af;
}
.status-dot { width: 8px; height: 8px; border-radius: 50%; background: #22c55e;
    animation: pulse 2s infinite; flex-shrink: 0; }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
.status-bar strong { color: #374151; }

/* ── Section header ── */
.section-header {
    display: flex; align-items: center; gap: 10px;
    margin-bottom: 16px; padding-bottom: 10px;
    border-bottom: 1px solid #e5e7eb;
}
.section-header h3 { margin: 0; font-size: 1rem; font-weight: 600; color: #111827; }

/* ── Route ranking table ── */
.route-table { width: 100%; border-collapse: collapse; }
.route-table th { background: #f3f4f6; color: #6b7280; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.07em; padding: 10px 14px; text-align: left; border-bottom: 1px solid #e5e7eb; }
.route-table td { padding: 10px 14px; border-bottom: 1px solid #f3f4f6; font-size: 0.86rem; color: #111827; }
.route-table tr:hover td { background: #f9fafb; }
.badge-healthy { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; border-radius: 20px; padding: 2px 10px; font-size: 0.72rem; font-weight: 600; }
.badge-moderate { background: #fffbeb; color: #d97706; border: 1px solid #fde68a; border-radius: 20px; padding: 2px 10px; font-size: 0.72rem; font-weight: 600; }
.badge-critical { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; border-radius: 20px; padding: 2px 10px; font-size: 0.72rem; font-weight: 600; }
.rank-num { font-weight: 700; color: #6366f1; font-size: 1.05rem; }

/* ── Recommendation cards ── */
.rec-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 14px; }
.rec-card { background: #ffffff; border: 1px solid #e5e7eb; border-radius: 10px; padding: 18px 20px; }
.rec-card.critical { border-left: 3px solid #ef4444; }
.rec-card.warning  { border-left: 3px solid #f59e0b; }
.rec-card.good     { border-left: 3px solid #22c55e; }
.rec-card.info     { border-left: 3px solid #6366f1; }
.rec-route { font-size: 1rem; font-weight: 700; color: #111827; margin-bottom: 6px; }
.rec-action { font-size: 0.82rem; color: #374151; font-weight: 500; margin-bottom: 6px; }
.rec-stats { display: flex; gap: 12px; margin-top: 10px; }
.rec-stat { font-size: 0.75rem; color: #9ca3af; }
.rec-stat span { color: #374151; font-weight: 600; }

/* ── Sidebar ── */
.sidebar-logo {
    display: flex; align-items: center; gap: 10px;
    padding: 16px 0 20px 0; border-bottom: 1px solid #e5e7eb; margin-bottom: 20px;
}
.sidebar-logo-text { font-size: 1rem; font-weight: 700; color: #111827; }
.sidebar-logo-text small { display: block; font-size: 0.68rem; color: #9ca3af; font-weight: 400; }
.sidebar-section { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.1em; color: #9ca3af; font-weight: 600; margin: 18px 0 8px 0; }
</style>
""", unsafe_allow_html=True)

# =====================================================================================
# CACHED PIPELINE
# =====================================================================================

@st.cache_resource(show_spinner=False)
def get_pipeline_results():
    return pipeline.run_pipeline(verbose=False)

def reset_pipeline_cache():
    get_pipeline_results.clear()


# =====================================================================================
# LOAD DATA
# =====================================================================================

with st.spinner(" Initialising UrbanPulse AI pipeline…"):
    results = get_pipeline_results()

cleaned_df   = results["cleaned_df"]
raw_df       = results["raw_df"]
etl_meta     = results["etl_meta"]
route_stats  = results["route_stats"]
ranking      = results["ranking"]
dashboard_fig = results["dashboard_fig"]
city_map     = results["city_map"]
map_stats    = results["map_stats"]

ranking_df = pd.DataFrame(ranking)
ranking_df.index = range(1, len(ranking_df) + 1)

# =====================================================================================
# HERO HEADER
# =====================================================================================

st.markdown("""
<div class="up-hero">
    <div class="up-logo-ring">🚌</div>
    <div class="up-hero-text">
        <h1>UrbanPulse</h1>
        <p class="tagline">Urban Mobility Intelligence Platform — Smart City Decision Support System</p>
        <div class="up-badges">
            <span class="up-badge">ETL Engine</span>
            <span class="up-badge">Merge Sort Ranking</span>
            <span class="up-badge">Geospatial Analytics</span>
            <span class="up-badge">Recommendation Engine</span>
            <span class="up-badge">Executive Dashboard</span>
        </div>
    </div>
</div>
""", unsafe_allow_html=True)

# Status bar
import datetime
now = datetime.datetime.now().strftime("%d %b %Y, %H:%M")
total_records = len(cleaned_df)
routes_count  = cleaned_df['route_id'].nunique()
avg_delay     = cleaned_df['delay_min'].mean()
avg_pass      = route_stats['avg_passengers'].mean()
critical_count = sum(1 for r in ranking if r['avg_delay_min'] > 14.5)



# =====================================================================================
# KPI CARDS
# =====================================================================================
mobility_health = max(0, min(100, int(100 - (critical_count / routes_count * 100) // 2 - (avg_delay / 18 * 20))))

st.markdown(f"""
<div class="kpi-grid">
    <div class="kpi-card">
        <div class="kpi-label">Total Routes</div>
        <div class="kpi-value">{routes_count}</div>
        <div class="kpi-sub">Active transit routes</div>
    </div>
    <div class="kpi-card">
        <div class="kpi-label">Avg Passengers</div>
        <div class="kpi-value">{avg_pass:,.0f}</div>
        <div class="kpi-sub">Per route average</div>
    </div>
    <div class="kpi-card">
        <div class="kpi-label">Avg Delay</div>
        <div class="kpi-value">{avg_delay:.1f}<span style="font-size:1rem;color:#64748b"> min</span></div>
        <div class="kpi-sub">Across all routes</div>
    </div>
    <div class="kpi-card">
        <div class="kpi-label">Critical Routes</div>
        <div class="kpi-sub">Delay &gt; 14.5 min</div>
        <div class="kpi-sub">Efficiency score &lt; 50</div>
    </div>
    <div class="kpi-card">
        <div class="kpi-label">Mobility Health</div>
        <div class="kpi-value" style="color:#4ade80">{mobility_health}%</div>
        <div class="kpi-sub">Overall network score</div>
    </div>
</div>
""", unsafe_allow_html=True)

st.markdown("---")

# =====================================================================================
# TABS
# =====================================================================================

tab_etl, tab_rank, tab_recs, tab_viz, tab_map, tab_downloads = st.tabs([
    "Data Quality Engine",
    "Route Intelligence",
    "Recommendations",
    "Analytics Dashboard",
    "Zone Intelligence",
    "Downloads",
])

# ─────────────────────────────────────────────────────────────────────────────
# TAB 1 — ETL / DATA QUALITY ENGINE
# ─────────────────────────────────────────────────────────────────────────────

with tab_etl:
    st.markdown('<div class="section-header"><span class="section-icon"></span><h3>Data Quality Engine — ETL Pipeline</h3></div>', unsafe_allow_html=True)
    st.caption("Automated ingestion, validation, and cleaning of raw bus ridership data across 50 transit routes.")

    # Summary metrics row
    nulls_before_total = int(etl_meta["nulls_before"].sum())
    nulls_after_total  = int(etl_meta["nulls_after"].sum())
    sentinel_count     = etl_meta["sentinel_count"]
    pct_cleaned        = 100.0 if nulls_before_total == 0 else (1 - nulls_after_total / nulls_before_total) * 100

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Raw Records", f"{len(raw_df):,}")
    m2.metric("Cleaned Records", f"{len(cleaned_df):,}")
    m3.metric("Issues Resolved", f"{nulls_before_total + sentinel_count}")
    m4.metric("Data Integrity", f"{pct_cleaned:.0f}%")

    st.markdown("---")
    col_a, col_b = st.columns([1, 1.4])

    with col_a:
        st.markdown("**Null counts — before vs after cleaning**")
        null_compare = pd.DataFrame(
            {"Before": etl_meta["nulls_before"], "After": etl_meta["nulls_after"]}
        ).fillna(0).astype(int)
        null_compare = null_compare[null_compare["Before"] > 0]
        st.dataframe(null_compare, use_container_width=True)
        st.metric("Sentinel `-999` rows replaced", sentinel_count)
        st.success(f"✅ All {nulls_before_total} null/sentinel issues resolved → {nulls_after_total} remaining")

    with col_b:
        st.markdown("**Null volume comparison (bar chart)**")
        st.bar_chart(null_compare)

    st.markdown("---")
    ic1, ic2, ic3 = st.columns(3)
    with ic1:
        st.markdown("**Zones (post-cleaning)**")
        st.dataframe(cleaned_df["zone"].value_counts().rename("rows"), use_container_width=True)
    with ic2:
        st.markdown("**Peak load distribution**")
        st.dataframe(cleaned_df["peak_load"].value_counts().rename("rows"), use_container_width=True)
    with ic3:
        st.markdown("**Passengers — summary stats**")
        st.dataframe(cleaned_df["passengers"].describe().round(1), use_container_width=True)

    st.markdown("---")
    show_raw = st.checkbox("Show raw (pre-cleaning) sample instead of cleaned data")
    preview_df = raw_df.head(25) if show_raw else cleaned_df.head(25)
    st.markdown(f"**Preview — {'raw' if show_raw else 'cleaned'} data (first 25 rows)**")
    st.dataframe(preview_df, use_container_width=True)

# ─────────────────────────────────────────────────────────────────────────────
# TAB 2 — ROUTE INTELLIGENCE (MERGE SORT RANKING)
# ─────────────────────────────────────────────────────────────────────────────

with tab_rank:
    st.markdown('<div class="section-header"><span class="section-icon"></span><h3>Route Intelligence — Merge Sort Ranking Engine</h3></div>', unsafe_allow_html=True)
    st.caption("Routes are ranked by a custom Merge Sort algorithm using Efficiency Score = avg_passengers / (1 + avg_delay_min).")

    n_routes = len(ranking_df)
    top_n = st.slider("Show top N routes", min_value=5, max_value=n_routes, value=15)

    def risk_badge(score):
        if score >= 400:
            return '<span class="badge-healthy">✅ Healthy</span>'
        elif score >= 200:
            return '<span class="badge-moderate">⚠️ Moderate</span>'
        else:
            return '<span class="badge-critical">🔴 Critical</span>'

    # Build HTML table
    rows_html = ""
    for rank_idx, row in ranking_df.head(top_n).iterrows():
        badge = risk_badge(row["efficiency_score"])
        rows_html += f"""
        <tr>
            <td><span class="rank-num">#{rank_idx}</span></td>
            <td><strong>{row['route_id']}</strong></td>
            <td>{row['avg_passengers']:.1f}</td>
            <td>{row['avg_delay_min']:.1f} min</td>
            <td><strong style="color:#38bdf8">{row['efficiency_score']:.2f}</strong></td>
        </tr>"""

    st.markdown(f"""
    <table class="route-table">
        <thead>
            <tr>
                <th>Rank</th><th>Route</th><th>Avg Passengers</th>
                <th>Avg Delay</th><th>Efficiency Score</th>
            </tr>
        </thead>
        <tbody>{rows_html}</tbody>
    </table>
    """, unsafe_allow_html=True)

    st.markdown("---")
    col_l, col_r = st.columns([1.6, 1])
    with col_l:
        st.markdown(f"**Top {top_n} efficiency scores (bar chart)**")
        st.bar_chart(ranking_df.head(top_n).set_index("route_id")["efficiency_score"])
    with col_r:
        st.markdown("**Bottom 5 routes — needs attention**")
        st.dataframe(
            ranking_df.tail(5).style.format(
                {"avg_passengers": "{:.1f}", "avg_delay_min": "{:.1f}", "efficiency_score": "{:.2f}"}
            ),
            use_container_width=True,
        )

    scores = ranking_df["efficiency_score"].tolist()
    is_sorted_ok = all(a >= b for a, b in zip(scores, scores[1:]))
    if is_sorted_ok:
        st.success("✅ Merge Sort correctness assertion passed: ranking is non-increasing.")
    else:
        st.error("❌ Ranking is NOT correctly sorted — check merge_sort() implementation.")

# ─────────────────────────────────────────────────────────────────────────────
# TAB 3 — RECOMMENDATION ENGINE
# ─────────────────────────────────────────────────────────────────────────────

with tab_recs:
    st.markdown('<div class="section-header"><span class="section-icon"></span><h3>Operational Recommendation Engine</h3></div>', unsafe_allow_html=True)
    st.caption("Rule-based decision support system that converts route analytics into actionable operational directives for transport planners.")

    def generate_recommendations(ranking_list):
        recs = []
        for r in ranking_list:
            passengers = r["avg_passengers"]
            delay      = r["avg_delay_min"]
            score      = r["efficiency_score"]
            route      = r["route_id"]

            if passengers > 3000 and delay > 14.5:
                recs.append({"route": route, "level": "critical",
                    "action": "🚌 Deploy Extra Bus",
                    "reason": "High passenger demand combined with elevated delay — capacity crisis.",
                    "passengers": passengers, "delay": delay, "score": score})
            elif delay > 14.5:
                recs.append({"route": route, "level": "critical",
                    "action": "🚦 Signal Optimization Required",
                    "reason": "Above-threshold delay detected. Traffic signal audit recommended.",
                    "passengers": passengers, "delay": delay, "score": score})
            elif score < 165:
                recs.append({"route": route, "level": "warning",
                    "action": "🔍 Infrastructure Audit",
                    "reason": "Low efficiency score. Investigate route design and stop spacing.",
                    "passengers": passengers, "delay": delay, "score": score})
            elif score < 235:
                recs.append({"route": route, "level": "info",
                    "action": "📋 Monitor Performance",
                    "reason": "Moderate efficiency. Track over next 30 days before adjusting.",
                    "passengers": passengers, "delay": delay, "score": score})
            else:
                recs.append({"route": route, "level": "good",
                    "action": "✅ Maintain Frequency",
                    "reason": "High-performing route. Sustain current operations.",
                    "passengers": passengers, "delay": delay, "score": score})
        return recs

    recs = generate_recommendations(ranking)

    st.markdown("**Ranking Decision Logic**")
    st.table(pd.DataFrame([
        {"Condition": "Passengers > 3000 AND Delay > 14.5 min", "Level": "🔴 Critical", "Action": "Deploy Extra Bus"},
        {"Condition": "Delay > 14.5 min",                       "Level": "🔴 Critical", "Action": "Signal Optimization"},
        {"Condition": "Efficiency Score < 165",                  "Level": "⚠️ Warning",  "Action": "Infrastructure Audit"},
        {"Condition": "Efficiency Score < 235",                  "Level": "📋 Monitor",  "Action": "Monitor Performance"},
        {"Condition": "Efficiency Score ≥ 235",                  "Level": "✅ Healthy",  "Action": "Maintain Frequency"},
    ]))

  
    # Summary counts
    rc1, rc2, rc3, rc4 = st.columns(4)
    rc1.metric("Total Directives", len(recs))
    rc2.metric("🔴 Critical", sum(1 for r in recs if r["level"] == "critical"))
    rc3.metric("⚠️ Warnings", sum(1 for r in recs if r["level"] == "warning"))
    rc4.metric("✅ Healthy", sum(1 for r in recs if r["level"] == "good"))

    st.markdown("---")

    filter_level = st.selectbox("Filter by priority", ["All", "Critical", "Warning", "Good", "Info"])
    filtered = recs if filter_level == "All" else [r for r in recs if r["level"] == filter_level.lower()]

    cards_html = '<div class="rec-grid">'
    for r in filtered:
        cards_html += f"""
        <div class="rec-card {r['level']}">
            <div class="rec-route">{r['route']}</div>
            <div class="rec-action">{r['action']}</div>
            <div style="font-size:0.8rem;color:#64748b;margin-bottom:10px">{r['reason']}</div>
            <div class="rec-stats">
                <div class="rec-stat">Passengers: <span>{r['passengers']:.0f}</span></div>
                <div class="rec-stat">Delay: <span>{r['delay']:.1f} min</span></div>
                <div class="rec-stat">Score: <span>{r['score']:.1f}</span></div>
            </div>
        </div>"""
    cards_html += '</div>'

    st.markdown(cards_html, unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# TAB 4 — ANALYTICS DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────

with tab_viz:
    st.markdown('<div class="section-header"><span class="section-icon"></span><h3>Executive Analytics Dashboard</h3></div>', unsafe_allow_html=True)
    st.caption("4-panel statistical dashboard — passenger trends, zone comparisons, delay distributions, and route scatter analysis.")
    st.pyplot(dashboard_fig, use_container_width=True)

# ─────────────────────────────────────────────────────────────────────────────
# TAB 5 — ZONE INTELLIGENCE MAP
# ─────────────────────────────────────────────────────────────────────────────

with tab_map:
    st.markdown('<div class="section-header"><span class="section-icon"></span><h3>Zone Intelligence — Geographic Mobility Map</h3></div>', unsafe_allow_html=True)
    st.caption("Interactive city-wide mobility health map with zone markers (color = load severity) and passenger heatmap layer.")

    mc1, mc2, mc3 = st.columns(3)
    mc1.metric("Zone Markers", map_stats["n_zone_markers"])
    mc2.metric("HeatMap Points", map_stats["n_heat_points"])
    mc3.metric("Zones Covered", len(pipeline.VALID_ZONES))

    zone_display = map_stats["zone_summary"].copy()
    zone_display["avg_passengers"] = zone_display["avg_passengers"].round(1)
    zone_display["avg_delay_min"]  = zone_display["avg_delay_min"].round(1)

    st.markdown("**Zone performance summary**")
    st.dataframe(zone_display, use_container_width=True)

    st_folium(city_map, use_container_width=True, height=520, returned_objects=[])

# ─────────────────────────────────────────────────────────────────────────────
# TAB 6 — DOWNLOADS
# ─────────────────────────────────────────────────────────────────────────────

with tab_downloads:
    st.markdown('<div class="section-header"><span class="section-icon"></span><h3>Export Artifacts</h3></div>', unsafe_allow_html=True)
    st.caption("Download all generated outputs — cleaned dataset, visual dashboard, and the interactive zone map.")

    dl1, dl2, dl3 = st.columns(3)
    with dl1:
        st.markdown("Cleaned Dataset")
        st.caption("ETL-processed ridership data (CSV)")
        with open(pipeline.CLEANED_CSV_PATH, "rb") as f:
            st.download_button("Download cleaned_ridership.csv", f,
                file_name=pipeline.CLEANED_CSV_PATH, mime="text/csv", use_container_width=True)
    with dl2:
        st.markdown("Analytics Dashboard")
        st.caption("4-panel statistical dashboard (PNG, 150 DPI)")
        with open(pipeline.DASHBOARD_PNG_PATH, "rb") as f:
            st.download_button("Download mobility_dashboard.png", f,
                file_name=pipeline.DASHBOARD_PNG_PATH, mime="image/png", use_container_width=True)
    with dl3:
        st.markdown("Zone Intelligence Map")
        st.caption("Interactive Folium map (HTML)")
        with open(pipeline.MAP_HTML_PATH, "rb") as f:
            st.download_button("Download city_mobility_map.html", f,
                file_name=pipeline.MAP_HTML_PATH, mime="text/html", use_container_width=True)

    st.markdown("---")
    st.caption(
        "UrbanPulse AI v1.0 · Built for Smart City Transport Authorities · "
        "ETL + Merge Sort + Matplotlib + Folium · Powered by Python & Streamlit"
    )

