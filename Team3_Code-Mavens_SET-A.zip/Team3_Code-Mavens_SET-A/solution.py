"""
Hackathon Set A - Urban Mobility Analytics
============================================
CLI entry point. All business logic lives in pipeline.py; this file is
intentionally thin so the same logic can be reused by the Streamlit
frontend (app.py) without duplicating code.

Run with:
    python solution.py

Outputs produced (in current working directory):
    cleaned_ridership.csv
    mobility_dashboard.png
    city_mobility_map.html
"""

from datetime import datetime

import matplotlib.pyplot as plt

import pipeline


def main() -> None:
    start_time = datetime.now()
    print("PYTHON DATA SCIENCE HACKATHON - SET A: URBAN MOBILITY ANALYTICS")
    print(f"Run started: {start_time.isoformat(timespec='seconds')}\n")

    results = pipeline.run_pipeline(verbose=True)

    # Free the matplotlib figure now that it's been saved to disk by the
    # pipeline - the CLI has no further use for the in-memory object.
    plt.close(results["dashboard_fig"])

    elapsed = (datetime.now() - start_time).total_seconds()
    print("\n" + "=" * 80)
    print(f"ALL TASKS COMPLETE. Total runtime: {elapsed:.2f}s")
    print("=" * 80)


if __name__ == "__main__":
    main()
